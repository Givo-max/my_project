# Givo Food Scanner

AI se photo dekh kar food pehchanta hai aur poori nutrition report deta hai —
calories, macros, vitamins, health score, allergy warnings, aur suitability
(weight loss / diabetics / heart / kids / elderly).

## Deploy karne ka tareeqa (mobile se, bina coding ke)

### 1. GitHub pe code upload karo
1. `github.com` pe account banao (agar nahi hai)
2. "New repository" bana lo, naam do: `givo-food-scanner` (Public ya Private, dono chalega)
3. Is poore folder ki saari files us repo mein upload kar do
   (GitHub website pe "Add file → Upload files" se seedha mobile se bhi ho jata hai —
   zip ke andar wali sab files select karo)

### 2. Vercel pe deploy karo
1. `vercel.com` pe jao → "Sign up" → **Continue with GitHub** (same account se login karo)
2. "Add New… → Project" → apni `givo-food-scanner` repo select karo → **Import**
3. Deploy se pehle **Environment Variables** section mein ye add karo:
   - Name: `ANTHROPIC_API_KEY`
   - Value: apni woh key jo `console.anthropic.com` se banayi thi (`sk-ant-...`)
4. **Deploy** button dabao — 1-2 minute mein live ho jayega
5. Vercel ek link dega jaisे `givo-food-scanner.vercel.app` — yehi apki live website hai

### 3. Baad mein badalna ho to
Koi bhi file GitHub pe edit karo (browser mein pencil icon se) → save karo →
Vercel apne aap 1 minute mein naya version deploy kar dega. Dobara upload karne
ki zaroorat nahi.

### 4. Apna domain lagana ho (jaise givofoodscanner.com)
Vercel project → Settings → Domains → apna domain add karo → jo DNS records
milen wo apni domain registrar (jahan se domain khareeda) ki settings mein daal do.

## App ke tor par deploy karna (baad ka step)

Yeh website already installable hai (Add to Home Screen se Android/iPhone dono
pe app jaisa icon ban jayega — koi extra kaam nahi). Agar Play Store /
App Store pe asli app chahiye, tab is website ko "wrap" karne ka tareeqa hoga
(jaise Capacitor ya Median.co ke zariye) — jab web version live ho jaye tab
yeh agla step kar lete hain.

## Local test (agar computer pe try karna ho)

```
npm install
cp .env.example .env.local   # phir .env.local mein apni real key daal do
npm run dev
```

Browser mein `http://localhost:3000` khol lo.
